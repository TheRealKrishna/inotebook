const mongoose = require("mongoose")
require('dotenv').config();
const mongoURI = process.env.mongoDBURI

const connectToMongo = async()=>{
    mongoose.connect(mongoURI, {dbName: 'inotebook'})
    console.log("Connected To Mongo Successfully!")
}

module.exports = connectToMongo;